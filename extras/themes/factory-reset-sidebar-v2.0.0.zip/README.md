# Factory Reset Sidebar 1.0.1

Child theme for Factory Reset 1.0.1.

Features:
- dark left sidebar
- Account and Administration submenus
- route-aware breadcrumb utility header
- Profile + Logout controls, or Register / Sign in when logged out
- full footer with social icons and Contact link
- four palettes from the approved light-theme mockup
- automatic Catto Learning palette deployment

Requires the revised Catto Learning Theme Package 3.0 palette contract that permits one or more palettes.
It will not install on the original v0.5.7 validator, which still requires exactly three palettes.
